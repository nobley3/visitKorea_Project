--------------------------------------------------------
--  ������ ������ - �ݿ���-12��-08-2023   
--------------------------------------------------------
REM INSERTING into SCOTT.USERTBL
SET DEFINE OFF;
Insert into SCOTT.USERTBL (USERID,NICKNAME,SORT,PW,SECTION,PROFILEURL) values ('jh0408','������','02','0000','01','https://spnimage.edaily.co.kr/images/Photo/files/NP/S/2017/12/PS17121900122.jpg');
Insert into SCOTT.USERTBL (USERID,NICKNAME,SORT,PW,SECTION,PROFILEURL) values ('kb0923','����','02','1111','01','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSNhnZD0g1l9QS1ThTlhNCSHW7JSOhMGp8Kyg&usqp=CAU');
Insert into SCOTT.USERTBL (USERID,NICKNAME,SORT,PW,SECTION,PROFILEURL) values ('mh1209','mh','02','2222','01','https://i.namu.wiki/i/fhe3U3XucDWci9s6ZPFI6OdDLqDb_F6JJeUUqN6PxRypuoHpP__3_553cq9qwLtcNd1BGNx7FJscxFRJpJ-w8A.webp');
Insert into SCOTT.USERTBL (USERID,NICKNAME,SORT,PW,SECTION,PROFILEURL) values ('admin','������1','01','admin1234!','01',null);
