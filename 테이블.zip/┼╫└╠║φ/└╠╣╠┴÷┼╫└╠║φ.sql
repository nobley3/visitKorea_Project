--------------------------------------------------------
--  ������ ������ - �ݿ���-12��-08-2023   
--------------------------------------------------------
REM INSERTING into SCOTT.IMGTBL
SET DEFINE OFF;
Insert into SCOTT.IMGTBL (IMGID,CONTENTID,IMGURL,IMGNUM) values ('I000000001','3027228','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=7317b7a9-69cd-4df9-87db-4fca075018d2',1);
Insert into SCOTT.IMGTBL (IMGID,CONTENTID,IMGURL,IMGNUM) values ('I000000002','3027228','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=cfbba548-3212-4d2c-8ca1-070fdd78fa00',2);
Insert into SCOTT.IMGTBL (IMGID,CONTENTID,IMGURL,IMGNUM) values ('I000000003','3027228','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=75ea84a7-5dda-4242-85f4-17e339574f3c',3);
Insert into SCOTT.IMGTBL (IMGID,CONTENTID,IMGURL,IMGNUM) values ('I000000004','3027098','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=85a6198d-b7a6-4e5e-b7c8-4cf618487c0c',1);
Insert into SCOTT.IMGTBL (IMGID,CONTENTID,IMGURL,IMGNUM) values ('I000000005','3027098','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=d0e81c2a-d95a-4fb9-b915-d00236814f81',2);
Insert into SCOTT.IMGTBL (IMGID,CONTENTID,IMGURL,IMGNUM) values ('I000000006','3027098','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=7251e39f-e976-4cdd-9024-7b2adbd88ad0',3);
Insert into SCOTT.IMGTBL (IMGID,CONTENTID,IMGURL,IMGNUM) values ('I000000013','3026235','https://cdn.visitkorea.or.kr/kfes/upload/contents/db/400_7c00aac5-7d42-4a8e-9cce-8805711b58a9_3.jpg',1);
Insert into SCOTT.IMGTBL (IMGID,CONTENTID,IMGURL,IMGNUM) values ('I000000014','3025685','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=c780a4eb-f9d3-4fb8-9799-a6d21cd181a9',1);
Insert into SCOTT.IMGTBL (IMGID,CONTENTID,IMGURL,IMGNUM) values ('I000000015','3025685','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=61f2e8bb-2db5-42d1-905d-b407f7032d37',2);
Insert into SCOTT.IMGTBL (IMGID,CONTENTID,IMGURL,IMGNUM) values ('I000000016','3025685','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=3a77e51d-fa51-4f93-96d4-cecb1df49568',3);
Insert into SCOTT.IMGTBL (IMGID,CONTENTID,IMGURL,IMGNUM) values ('I000000017','3025685','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=8caf2bd5-47bb-4cc5-b0c7-10f22f96167e',4);
Insert into SCOTT.IMGTBL (IMGID,CONTENTID,IMGURL,IMGNUM) values ('I000000021','2540131','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=d1d1850e-a3e5-4743-8457-e1af5d3879b8',1);
Insert into SCOTT.IMGTBL (IMGID,CONTENTID,IMGURL,IMGNUM) values ('I000000023','2540131','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=35c613b6-a254-41a1-9a94-80f1c51d5d5e',3);
Insert into SCOTT.IMGTBL (IMGID,CONTENTID,IMGURL,IMGNUM) values ('I000000027','2823794','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=e3f3fb81-f492-4dba-a3fa-0e51509bb2d1',1);
Insert into SCOTT.IMGTBL (IMGID,CONTENTID,IMGURL,IMGNUM) values ('I000000028','2823794','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=f466fcae-7a1b-42c9-9f7a-7caabf9a303d',2);
Insert into SCOTT.IMGTBL (IMGID,CONTENTID,IMGURL,IMGNUM) values ('I000000029','2823794','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=be3fabf2-a4c0-4d49-ad55-85e7e416175b',3);
Insert into SCOTT.IMGTBL (IMGID,CONTENTID,IMGURL,IMGNUM) values ('I000000022','2540131','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=f538bad1-9883-4f38-bfee-079631918d80',2);
Insert into SCOTT.IMGTBL (IMGID,CONTENTID,IMGURL,IMGNUM) values ('I000000007','3026312','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=8ecd0f6d-30b0-49f4-b223-23ffd1ebb127',1);
Insert into SCOTT.IMGTBL (IMGID,CONTENTID,IMGURL,IMGNUM) values ('I000000008','3026312','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=f5376c42-f1f0-4283-b87d-c31d8a628851',2);
Insert into SCOTT.IMGTBL (IMGID,CONTENTID,IMGURL,IMGNUM) values ('I000000009','3026312','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=ccb06e0d-7446-4854-bbea-d44b6dfd745c',3);
Insert into SCOTT.IMGTBL (IMGID,CONTENTID,IMGURL,IMGNUM) values ('I000000010','3026312','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=c30b61c8-0df3-49af-9fc4-b79cf4b4c6d3',4);
Insert into SCOTT.IMGTBL (IMGID,CONTENTID,IMGURL,IMGNUM) values ('I000000011','3026969','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=542e3b3f-4749-4e7e-aa7b-e23bdc68f1a8',1);
Insert into SCOTT.IMGTBL (IMGID,CONTENTID,IMGURL,IMGNUM) values ('I000000012','3026969','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=93380178-d25f-423b-8f11-4be2b13d5646',2);
