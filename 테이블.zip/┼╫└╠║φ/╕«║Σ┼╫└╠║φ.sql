--------------------------------------------------------
--  ������ ������ - �ݿ���-12��-08-2023   
--------------------------------------------------------
REM INSERTING into SCOTT.REVIEWTBL
SET DEFINE OFF;
Insert into SCOTT.REVIEWTBL (REVIEWCODE,USERID,WRITEDAY,CONTENTID,PARENTCODE) values (20,'kb0923',to_date('23/11/30','RR/MM/DD'),'3027228',0);
Insert into SCOTT.REVIEWTBL (REVIEWCODE,USERID,WRITEDAY,CONTENTID,PARENTCODE) values (17,'jh0408',to_date('23/11/30','RR/MM/DD'),'3027228',0);
Insert into SCOTT.REVIEWTBL (REVIEWCODE,USERID,WRITEDAY,CONTENTID,PARENTCODE) values (24,'jh0408',to_date('23/11/30','RR/MM/DD'),'3027228',20);
