--------------------------------------------------------
--  ������ ������ - �ݿ���-12��-08-2023   
--------------------------------------------------------
REM INSERTING into SCOTT.LIKETBL
SET DEFINE OFF;
Insert into SCOTT.LIKETBL (USERID,CONTENTID) values ('jh0408','2540131');
Insert into SCOTT.LIKETBL (USERID,CONTENTID) values ('jh0408','2823801');
Insert into SCOTT.LIKETBL (USERID,CONTENTID) values ('jh0408','2823807');
Insert into SCOTT.LIKETBL (USERID,CONTENTID) values ('jh0408','2994565');
Insert into SCOTT.LIKETBL (USERID,CONTENTID) values ('jh0408','3025685');
Insert into SCOTT.LIKETBL (USERID,CONTENTID) values ('jh0408','3026041');
Insert into SCOTT.LIKETBL (USERID,CONTENTID) values ('jh0408','3027228');
Insert into SCOTT.LIKETBL (USERID,CONTENTID) values ('jh0408','3036761');
Insert into SCOTT.LIKETBL (USERID,CONTENTID) values ('jh0408','3036763');
